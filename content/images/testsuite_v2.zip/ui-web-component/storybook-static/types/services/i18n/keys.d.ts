export interface MarkdownEditorI18nKeys {
    headerDefault: string;
    headerNormalText: string;
    headerTitlePrefix: string;
    headerLabelPrefix: string;
    boldTitle: string;
    italicTitle: string;
    toggleMenuTitle: string;
    strikeTitle: string;
    strikeLabel: string;
    subTitle: string;
    subLabel: string;
    superTitle: string;
    superLabel: string;
    ulTitle: string;
    olTitle: string;
    parentTitle: string;
    joinTitle: string;
    liftTitle: string;
    codeBlockTitle: string;
    codeBlockLabel: string;
    blockquoteTitle: string;
    blockquoteLabel: string;
    hrTitle: string;
    hrLabel: string;
    markdownModeLabel: string;
    markdownModeTitle: string;
    visualModeLabel: string;
    visualModeTitle: string;
    insertMenuTitle: string;
    linkTitle: string;
    linkPromptTitle: string;
    linkPromptTextPlaceholder: string;
    linkPromptHrefPlaceholder: string;
    imageTitle: string;
    imageLabel: string;
    imagePromptTitle: string;
    imagePromptFieldLocation: string;
    imagePromptFieldTitle: string;
    imagePromptFieldDescription: string;
}
export declare type MarkdownEditorI18nKey = keyof MarkdownEditorI18nKeys;
export interface MarkdownEditorI18n {
    [key: string]: MarkdownEditorI18nKeys;
}
