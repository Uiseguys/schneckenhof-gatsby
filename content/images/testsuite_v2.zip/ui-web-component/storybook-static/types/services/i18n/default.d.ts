import { MarkdownEditorI18n } from './keys';
export declare const defaultI18n: MarkdownEditorI18n;
