export declare const visualMenu: (lang: any, icons: any) => import("prosemirror-state").Plugin<any, any>;
