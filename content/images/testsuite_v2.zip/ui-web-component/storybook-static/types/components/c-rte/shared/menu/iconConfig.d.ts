import { IconConfigContainer } from './buttonType';
export declare const iconConfig: IconConfigContainer;
