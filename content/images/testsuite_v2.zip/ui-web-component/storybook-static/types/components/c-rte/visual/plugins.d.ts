export declare const visualPlugins: (lang: any, icons: any) => any[];
