/**
 * This helper functions are forked from https://github.com/ProseMirror/prosemirror-example-setup
 * Can be published to npm as separate package `prosemirror-markdown-setup` or similar.
*/
import { MenuItem } from 'prosemirror-menu';
import { ButtonType, IconLabels } from './buttonType';
export declare function canInsert(state: any, nodeType: any): boolean;
export declare function cmdItem(cmd: any, options: any): MenuItem<any>;
export declare function markActive(state: any, type: any): any;
export declare function markItem(markType: any, options: any): MenuItem<any>;
export declare function wrapListItem(nodeType: any, options: any): MenuItem<any>;
export declare function replaceMark(markType: any, attrs?: {}): (state: any, dispatch: any) => boolean;
export declare function constructIcon(theme: string, type: ButtonType, labelData?: IconLabels): {
    dom: any;
};
