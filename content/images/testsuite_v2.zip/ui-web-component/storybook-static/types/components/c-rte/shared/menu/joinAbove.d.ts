export declare const joinUpItem: (title: any) => void;
