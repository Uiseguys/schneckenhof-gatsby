import { MenuItem } from 'prosemirror-menu';
export interface LinkTranslationData {
    title: string;
    linkPromptTitle: string;
    linkPromptHrefPlaceholder: string;
    linkPromptTextPlaceholder: string;
}
export declare function linkItem(markType: any, iconTheme: string, translation: LinkTranslationData): MenuItem<any>;
