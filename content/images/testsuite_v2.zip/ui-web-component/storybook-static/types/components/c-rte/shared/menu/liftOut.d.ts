import { MenuItem } from 'prosemirror-menu';
export declare const liftItem: (title: any) => MenuItem<any>;
