import { MenuItem } from 'prosemirror-menu';
export declare const selectParentButton: (title: string) => MenuItem<any>;
