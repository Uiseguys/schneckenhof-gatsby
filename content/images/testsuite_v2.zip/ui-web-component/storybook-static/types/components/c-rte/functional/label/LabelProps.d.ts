export interface LabelProps {
    id: string;
    isRequired: boolean;
    label: string;
    errorText: string;
    helptext: string;
}
