import { EventEmitter } from '../../stencil.core';
import { MarkdownEditorI18n } from '../../services/i18n/keys';
import { IconThemeType } from './shared/menu/buttonType';
/**
 * Markdown component class
 *
 * @Prop editable { boolean } is editable property
 * @Prop value { string } initial value of editor
 * @class CwcWysiwygMarkdownEditor
 */
export declare class CwcWysiwygMarkdownEditor {
    private get parsedWithMD();
    visualMode: boolean;
    markdownUpdated: EventEmitter;
    language: string;
    translationKeys: MarkdownEditorI18n;
    icons: IconThemeType;
    editorId: string;
    isRequired: boolean;
    label: string;
    errorText: string;
    helptext: string;
    private translation;
    editable: boolean;
    value: string;
    private visualView;
    private rawView;
    private el;
    private textToRender;
    valueChangeHandler(newValue: string): void;
    componentWillLoad(): void;
    componentDidLoad(): void;
    render(): any[];
    handleKeyDown(evt: KeyboardEvent): void;
    private i18n;
    private initVisualView;
    private createVisualState;
    private createRawState;
    private initRawView;
    /**
     *  Serialize/parse functions
     */
    private serializeWithMD;
    /**
     *  State change handlers
     */
    private handleExportToRaw;
    private handleExportToVisual;
    private onEditorUpdateHook;
    private onRawEditorUpdateHook;
    /**
     * Private service functions
     */
    private setEditorMode;
    private appendMenuActiveClass;
}
