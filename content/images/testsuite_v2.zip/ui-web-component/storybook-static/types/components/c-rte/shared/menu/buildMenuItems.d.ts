import { MarkdownEditorI18nKey } from '../../../../services/i18n/keys';
export declare function buildMenuItems(schema: any, iconTheme: string, i18n: (k: MarkdownEditorI18nKey) => string): any;
