import { MenuItem } from 'prosemirror-menu';
export interface ImageTranslateData {
    imageTitle: string;
    imageLabel: string;
    imagePromptTitle: string;
    imagePromptFieldLocation: string;
    imagePromptFieldTitle: string;
    imagePromptFieldDescription: string;
}
export declare function imageItem(nodeType: any, translate: ImageTranslateData): MenuItem<any>;
