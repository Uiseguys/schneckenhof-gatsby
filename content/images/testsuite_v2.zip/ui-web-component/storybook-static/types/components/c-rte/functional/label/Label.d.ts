import { FunctionalComponent } from '../../../../stencil.core';
import { LabelProps } from './LabelProps';
export declare const Label: FunctionalComponent<LabelProps>;
