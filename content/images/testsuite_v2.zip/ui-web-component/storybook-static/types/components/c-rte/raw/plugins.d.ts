export declare const rawPlugins: (lang: any, icons: any) => any[];
