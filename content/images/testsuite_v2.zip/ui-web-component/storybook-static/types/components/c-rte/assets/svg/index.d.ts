export interface MarkdownEditorIconSet {
    bold: string;
    italic: string;
    ul: string;
    ol: string;
    link: string;
    horisontalRule: string;
    blockquote: string;
    code: string;
}
export declare const set: MarkdownEditorIconSet;
