export declare function openPrompt(options: any): void;
export declare class Field {
    options: any;
    constructor(options: any);
    read(dom: any): any;
    validateType(_value: any): void;
    validate(): void;
    clean(value: any): any;
}
export declare class TextField extends Field {
    render(): HTMLInputElement;
}
export declare class SelectField extends Field {
    render(): HTMLSelectElement;
}
