export declare const rawMenu: (lang: any, icons: any) => import("prosemirror-state").Plugin<any, any>;
