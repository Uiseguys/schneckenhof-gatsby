import { EventEmitter } from '../../stencil.core';
export declare class MyButton {
    klick: EventEmitter;
    label: string;
    handleClick(event: UIEvent): void;
    componentWillLoad(): void;
    render(): any;
}
