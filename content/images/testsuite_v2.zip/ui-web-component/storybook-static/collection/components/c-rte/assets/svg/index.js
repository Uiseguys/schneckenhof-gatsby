import blockquote from './blockquote.svg';
import bold from './bold.svg';
import code from './code.svg';
import horisontalRule from './horisontal-rule.svg';
import italic from './italic.svg';
import link from './link.svg';
import ol from './ol.svg';
import ul from './ul.svg';
export const set = {
    bold,
    blockquote,
    ul,
    ol,
    code,
    italic,
    horisontalRule,
    link,
};
