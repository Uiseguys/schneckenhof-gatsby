import { MenuItem } from 'prosemirror-menu';
import { NodeSelection } from 'prosemirror-state';
import { openPrompt, TextField } from '../prompt';
import { canInsert } from './menuHelpers';
export function imageItem(nodeType, translate) {
    return new MenuItem({
        title: translate.imageTitle,
        label: translate.imageLabel,
        enable(state) { return canInsert(state, nodeType); },
        run(state, _, view) {
            const { from, to } = state.selection;
            let attrs = null;
            if (state.selection instanceof NodeSelection && state.selection.node.type === nodeType) {
                attrs = state.selection.node.attrs;
            }
            openPrompt({
                title: translate.imagePromptTitle,
                fields: {
                    src: new TextField({
                        label: translate.imagePromptFieldLocation, required: true, value: attrs && attrs.src
                    }),
                    title: new TextField({ label: translate.imagePromptFieldTitle, value: attrs && attrs.title }),
                    alt: new TextField({
                        label: translate.imagePromptFieldDescription,
                        value: attrs ? attrs.alt : state.doc.textBetween(from, to, ' '),
                    }),
                },
                // tslint:disable-next-line
                callback(attrs) {
                    view.dispatch(view.state.tr.replaceSelectionWith(nodeType.createAndFill(attrs)));
                    view.focus();
                },
            });
        },
        css: '',
        class: '',
        execEvent: '',
    });
}
