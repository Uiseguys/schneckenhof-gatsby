import { lift } from 'prosemirror-commands';
import { MenuItem } from 'prosemirror-menu';
import { constructIcon } from './menuHelpers';
// tslint:disable-next-line:arrow-parens
export const liftItem = title => new MenuItem({
    title,
    run: lift,
    select: (state) => lift(state),
    icon: constructIcon('material', "liftOut" /* LIFT_OUT */),
    execEvent: '',
    css: '',
    class: '',
});
