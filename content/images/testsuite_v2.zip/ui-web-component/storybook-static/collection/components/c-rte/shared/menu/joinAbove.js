import { joinUp } from 'prosemirror-commands';
import { MenuItem } from 'prosemirror-menu';
import { constructIcon } from './menuHelpers';
// tslint:disable-next-line:arrow-parens
export const joinUpItem = title => {
    new MenuItem({
        title: 'Join with above block',
        run: joinUp,
        select: (state) => joinUp(state),
        icon: constructIcon('material', "joinUp" /* JOIN_UP */, { title }),
        execEvent: '',
        css: '',
        class: '',
    });
};
