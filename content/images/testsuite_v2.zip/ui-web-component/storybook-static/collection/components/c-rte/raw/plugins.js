import { baseKeymap, toggleMark } from 'prosemirror-commands';
import { exampleSetup } from 'prosemirror-example-setup';
import { redo, undo } from 'prosemirror-history';
import { keymap } from 'prosemirror-keymap';
import { buildInputRules } from '../shared/input-rules';
import { rawMenu } from './menu';
import { rawMarkdownSchema } from './schema';
const histKeymap = keymap({ 'Mod-z': undo, 'Mod-y': redo });
const starKeymap = keymap({
    'Ctrl-b': toggleMark(rawMarkdownSchema.marks.strong),
    'Ctrl-q': toggleLink,
    'Ctrl-Space': insertStar,
});
function toggleLink(state, dispatch) {
    const { doc, selection } = state;
    if (selection.empty) {
        return false;
    }
    let attrs = null;
    if (!doc.rangeHasMark(selection.from, selection.to, rawMarkdownSchema.marks.strong)) {
        attrs = { href: prompt('Link to where?', '') };
        if (!attrs.href) {
            return false;
        }
    }
    return toggleMark(rawMarkdownSchema.marks.link, attrs)(state, dispatch);
}
// TODO: remove
function insertStar(state, dispatch) {
    const type = rawMarkdownSchema.nodes.star;
    const { $from } = state.selection;
    if (!$from.parent.canReplaceWith($from.index(), $from.index(), type)) {
        return false;
    }
    dispatch(state.tr.replaceSelectionWith(type.create()));
    return true;
}
// tslint:disable-next-line:arrow-parens
export const rawPlugins = (lang, icons) => [
    ...exampleSetup({ schema: rawMarkdownSchema, menuBar: false }),
    buildInputRules(rawMarkdownSchema),
    histKeymap,
    starKeymap,
    rawMenu(lang, icons),
    keymap(baseKeymap),
];
