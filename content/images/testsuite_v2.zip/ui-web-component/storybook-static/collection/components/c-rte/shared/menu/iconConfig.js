export const iconConfig = {
    strong: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'format_bold',
            },
        },
        materialDe: {
            className: 'material-icons-de',
            icon: {
                text: 'F',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-bold',
            },
            className: 'tbd',
        },
    },
    em: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'format_italic',
            },
        },
        materialDe: {
            className: 'material-icons-de',
            icon: {
                text: 'K',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-italic',
            },
            className: 'tbd',
        },
    },
    ul: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'format_list_bulleted',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'format_list_bulleted',
            },
        },
        atlassian: {
            className: 'icon-ul',
            icon: { text: '' },
        },
    },
    ol: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'format_list_numbered',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'format_list_numbered',
            },
        },
        atlassian: {
            className: 'icon-ol',
            icon: {
                text: '',
            },
        },
    },
    link: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'insert_link',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'insert_link',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-link',
            },
            className: 'tbd',
        },
    },
    blockquote: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'format_quote',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'format_quote',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-blockquote',
            },
            className: 'tbd',
        },
    },
    codeblock: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'code',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'code',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-blockquote',
            },
            className: 'tbd',
        },
    },
    hr: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'remove',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'remove',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-blockquote',
            },
            className: 'tbd',
        },
    },
    parentNode: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'settings_overscan',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'settings_overscan',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-bold',
            },
            className: 'tbd',
        },
    },
    liftOut: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'format_indent_decrease',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'format_indent_decrease',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-bold',
            },
            className: 'tbd',
        },
    },
    joinUp: {
        material: {
            className: 'material-icons',
            icon: {
                text: 'vertical_align_top',
            },
        },
        materialDe: {
            className: 'material-icons',
            icon: {
                text: 'vertical_align_top',
            },
        },
        atlassian: {
            icon: {
                text: 'icon-bold',
            },
            className: 'tbd',
        },
    },
};
