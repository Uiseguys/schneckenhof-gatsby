import { h } from "@stencil/core";
import { DOMParser } from 'prosemirror-model';
import { EditorState } from 'prosemirror-state';
import { setTextSelection } from 'prosemirror-utils';
import { EditorView } from 'prosemirror-view';
import { defaultI18n } from '../../services/i18n/default';
import { translate } from '../../services/i18n/translate';
import { Label } from './functional/label';
import { rawMarkdownSchema, rawPlugins } from './raw';
import { getCurrentNodes, omitEscape, randomId, updateViewWithTransaction } from './shared/utils';
import { visualMarkdownParser, visualMarkdownSerializer, visualPlugins } from './visual';
/**
 * Markdown component class
 *
 * @Prop editable { boolean } is editable property
 * @Prop value { string } initial value of editor
 * @class CwcWysiwygMarkdownEditor
 */
export class CwcWysiwygMarkdownEditor {
    constructor() {
        this.visualMode = true;
        this.language = 'en';
        this.icons = 'material';
        this.editorId = randomId();
        this.isRequired = false;
        this.translation = defaultI18n;
        this.editable = true;
        this.value = '';
        this.textToRender = `## Heading 2
  plain text
  #### Heading 4`;
        this.i18n = (key) => translate(key, this.language, this.translation);
    }
    get parsedWithMD() {
        return visualMarkdownParser.parse(this.textToRender);
    }
    valueChangeHandler(newValue) {
        this.textToRender = newValue;
        this.visualView.updateState(this.createVisualState());
        this.rawView.updateState(this.createRawState());
    }
    componentWillLoad() {
        this.textToRender = this.value;
        this.markdownUpdated.emit(this.textToRender);
    }
    componentDidLoad() {
        /**
         * Initialization of ProseMirror editor and it state
         */
        this.visualView = this.initVisualView();
        this.rawView = this.initRawView();
        this.handleExportToRaw();
        this.translation = Object.assign(Object.assign({}, defaultI18n), this.translationKeys);
    }
    render() {
        return [
            h("div", { class: "editor-wrapper px-5 pt-2" },
                h(Label, { id: `${this.editorId}-label`, isRequired: this.isRequired, label: this.label, errorText: this.errorText, helptext: this.helptext }),
                h("div", { id: "editor", class: 'editor visual ' + this.language + ' ' + this.icons }),
                h("div", { id: "raw-editor", class: 'editor raw hidden ' + this.language + ' ' + this.icons })),
            h("div", { class: "mode-selector ml-5 mb-2" },
                h("button", { class: "btn btn-outline-primary btn-sm ml-1", disabled: this.visualMode, onClick: () => this.setEditorMode(true), title: this.i18n('visualModeTitle') }, this.i18n('visualModeLabel')),
                h("button", { class: "btn btn-outline-primary btn-sm ml-1", disabled: !this.visualMode, onClick: () => this.setEditorMode(false), title: this.i18n('markdownModeTitle') }, this.i18n('markdownModeLabel'))),
            h("div", { id: "raw-content", class: "raw raw-content" })
        ];
    }
    handleKeyDown(evt) {
        if (evt.keyCode === 80 && evt.shiftKey === true && evt.shiftKey === true) {
            evt.preventDefault();
            this.setEditorMode(!this.visualMode);
        }
    }
    initVisualView(state = this.createVisualState()) {
        return new EditorView(this.el.querySelector('.editor.visual'), {
            state,
            dispatchTransaction: this.onEditorUpdateHook.bind(this),
            editable: () => this.editable,
        });
    }
    createVisualState(doc = this.parsedWithMD) {
        const plugins = visualPlugins(this.i18n, this.icons);
        return EditorState.create({ doc, plugins });
    }
    createRawState() {
        const doc = DOMParser.fromSchema(rawMarkdownSchema).parse(document.getElementById('raw-content'));
        return EditorState.create({ doc, plugins: rawPlugins(this.i18n, this.icons) });
    }
    initRawView() {
        return new EditorView(this.el.querySelector('.editor.raw'), {
            state: this.createRawState(),
            dispatchTransaction: this.onRawEditorUpdateHook.bind(this),
        });
    }
    /**
     *  Serialize/parse functions
     */
    serializeWithMD(view = this.visualView) {
        return visualMarkdownSerializer.serialize(view.state.doc);
    }
    /**
     *  State change handlers
     */
    handleExportToRaw() {
        this.el.querySelector('#raw-content').innerHTML =
            this.el.querySelector('.ProseMirror.ProseMirror-example-setup-style').innerHTML;
        this.rawView.updateState(this.createRawState());
    }
    handleExportToVisual() {
        const serialized = this.serializeWithMD(this.rawView);
        this.visualView.updateState(this.createVisualState(visualMarkdownParser.parse(omitEscape(serialized))));
    }
    onEditorUpdateHook(tr) {
        updateViewWithTransaction(this.visualView, tr);
        if (tr.docChanged) {
            this.markdownUpdated.emit(this.serializeWithMD());
            this.handleExportToRaw();
        }
        this.appendMenuActiveClass();
    }
    onRawEditorUpdateHook(tr) {
        updateViewWithTransaction(this.rawView, tr);
        if (tr.docChanged) {
            this.markdownUpdated.emit(omitEscape(this.serializeWithMD(this.rawView)));
            this.handleExportToVisual();
        }
        this.appendMenuActiveClass();
    }
    /**
     * Private service functions
     */
    setEditorMode(mode, focus = this.editable) {
        const visual = this.el.querySelector('.editor.visual');
        const raw = this.el.querySelector('.editor.raw');
        if (mode) {
            raw.classList.add('hidden');
            visual.classList.remove('hidden');
            const editor = visual.querySelector('.ProseMirror');
            if (focus) {
                setTimeout(() => {
                    editor.focus();
                    this.visualView.state.apply(setTextSelection(0, 2)(this.visualView.state.tr));
                }, 0);
            }
            this.handleExportToVisual();
            this.visualMode = true;
        }
        else if (!mode) {
            visual.classList.add('hidden');
            raw.classList.remove('hidden');
            const editor = raw.querySelector('.ProseMirror');
            if (focus) {
                setTimeout(() => {
                    editor.focus();
                    // this.rawView.state.tr.
                }, 0);
            }
            this.handleExportToRaw();
            this.visualMode = false;
        }
    }
    appendMenuActiveClass() {
        const currentNodes = getCurrentNodes(this.visualMode ? this.visualView : this.rawView);
        const inputModeClasses = [
            'active-heading-1',
            'active-heading-2',
            'active-heading-3',
            'active-heading-4',
            'active-heading-5',
            'active-heading-6',
            'paragraph',
        ];
        const dropdownEl = this.el.querySelector(`.editor${this.visualMode ? '.visual' : '.raw'} .ProseMirror-menubar .ProseMirror-menu-dropdown-wrap`);
        if (currentNodes.length === 0 || currentNodes.length === 1) {
            inputModeClasses.map((val) => dropdownEl.classList.toggle(val, val === currentNodes[0]));
            if (currentNodes.length === 0) {
                inputModeClasses.map((val) => dropdownEl.classList.toggle(val, dropdownEl.classList.contains(val)));
            }
        }
    }
    static get is() { return "c-rte"; }
    static get originalStyleUrls() { return {
        "$": ["styles/_main.scss", "cwc-wysiwyg-markdown-editor.scss", "style.css"]
    }; }
    static get styleUrls() { return {
        "$": ["styles/_main.css", "cwc-wysiwyg-markdown-editor.css", "style.css"]
    }; }
    static get properties() { return {
        "visualMode": {
            "type": "boolean",
            "mutable": true,
            "complexType": {
                "original": "boolean",
                "resolved": "boolean",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "visual-mode",
            "reflect": false,
            "defaultValue": "true"
        },
        "language": {
            "type": "string",
            "mutable": false,
            "complexType": {
                "original": "string",
                "resolved": "string",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "language",
            "reflect": false,
            "defaultValue": "'en'"
        },
        "translationKeys": {
            "type": "unknown",
            "mutable": false,
            "complexType": {
                "original": "MarkdownEditorI18n",
                "resolved": "MarkdownEditorI18n",
                "references": {
                    "MarkdownEditorI18n": {
                        "location": "import",
                        "path": "../../services/i18n/keys"
                    }
                }
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            }
        },
        "icons": {
            "type": "string",
            "mutable": false,
            "complexType": {
                "original": "IconThemeType",
                "resolved": "\"atlassian\" | \"material\" | \"materialDe\"",
                "references": {
                    "IconThemeType": {
                        "location": "import",
                        "path": "./shared/menu/buttonType"
                    }
                }
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "icons",
            "reflect": false,
            "defaultValue": "'material'"
        },
        "editorId": {
            "type": "string",
            "mutable": false,
            "complexType": {
                "original": "string",
                "resolved": "string",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "editor-id",
            "reflect": false,
            "defaultValue": "randomId()"
        },
        "isRequired": {
            "type": "boolean",
            "mutable": false,
            "complexType": {
                "original": "boolean",
                "resolved": "boolean",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "is-required",
            "reflect": false,
            "defaultValue": "false"
        },
        "label": {
            "type": "string",
            "mutable": false,
            "complexType": {
                "original": "string",
                "resolved": "string",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "label",
            "reflect": false
        },
        "errorText": {
            "type": "string",
            "mutable": false,
            "complexType": {
                "original": "string",
                "resolved": "string",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "error-text",
            "reflect": false
        },
        "helptext": {
            "type": "string",
            "mutable": false,
            "complexType": {
                "original": "string",
                "resolved": "string",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "helptext",
            "reflect": false
        },
        "editable": {
            "type": "boolean",
            "mutable": false,
            "complexType": {
                "original": "boolean",
                "resolved": "boolean",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "editable",
            "reflect": false,
            "defaultValue": "true"
        },
        "value": {
            "type": "string",
            "mutable": true,
            "complexType": {
                "original": "string",
                "resolved": "string",
                "references": {}
            },
            "required": false,
            "optional": false,
            "docs": {
                "tags": [],
                "text": ""
            },
            "attribute": "value",
            "reflect": false,
            "defaultValue": "''"
        }
    }; }
    static get states() { return {
        "textToRender": {}
    }; }
    static get events() { return [{
            "method": "markdownUpdated",
            "name": "markdownUpdated",
            "bubbles": true,
            "cancelable": true,
            "composed": true,
            "docs": {
                "tags": [],
                "text": ""
            },
            "complexType": {
                "original": "any",
                "resolved": "any",
                "references": {}
            }
        }]; }
    static get elementRef() { return "el"; }
    static get watchers() { return [{
            "propName": "value",
            "methodName": "valueChangeHandler"
        }]; }
    static get listeners() { return [{
            "name": "keydown",
            "method": "handleKeyDown",
            "target": undefined,
            "capture": false,
            "passive": false
        }]; }
}
