import { menuBar } from 'prosemirror-menu';
import { buildMenuItems } from '../shared/menu/buildMenuItems';
import { schema } from './schema';
// import { IconThemeType } from '../shared/menu/buttonType';
export const visualMenu = (lang, icons) => menuBar({ content: buildMenuItems(schema, icons, lang).fullMenu });
