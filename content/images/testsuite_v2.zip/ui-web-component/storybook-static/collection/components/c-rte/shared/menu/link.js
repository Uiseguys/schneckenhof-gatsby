import { MenuItem } from 'prosemirror-menu';
import { openPrompt, TextField } from '../prompt';
import { constructIcon, markActive, replaceMark } from './menuHelpers';
export function linkItem(markType, iconTheme = 'material', translation) {
    const { title, linkPromptTitle, linkPromptHrefPlaceholder, linkPromptTextPlaceholder } = translation;
    return new MenuItem({
        title,
        active(state) { return markActive(state, markType); },
        enable(state) { return !state.selection.empty; },
        run(state, dispatch, view) {
            if (markActive(state, markType)) {
                replaceMark(markType)(state, dispatch);
                return true;
            }
            openPrompt({
                title: linkPromptTitle,
                fields: {
                    href: new TextField({
                        label: linkPromptHrefPlaceholder,
                        required: true,
                    }),
                    title: new TextField({ label: linkPromptTextPlaceholder }),
                },
                callback(attrs) {
                    replaceMark(markType, attrs)(view.state, view.dispatch);
                    view.focus();
                },
            });
        },
        css: '',
        class: '',
        label: '',
        execEvent: '',
        icon: constructIcon(iconTheme, "link" /* LINK */),
    });
}
