import { selectParentNode } from 'prosemirror-commands';
import { MenuItem } from 'prosemirror-menu';
import { constructIcon } from './menuHelpers';
export const selectParentButton = (title) => new MenuItem({
    title,
    run: selectParentNode,
    select: (state) => selectParentNode(state),
    icon: constructIcon('material', "parentNode" /* PARENT_NODE */),
    css: '',
    class: '',
    label: '',
    execEvent: ' ',
});
