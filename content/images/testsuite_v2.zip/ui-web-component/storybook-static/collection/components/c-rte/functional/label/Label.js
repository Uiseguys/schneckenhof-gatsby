import { h } from "@stencil/core";
export /**
 *  Markup component provides form control label.
 *
 * @param LabelProps props
 */ const Label = (props) => h("label", { htmlFor: props.id, class: `control-label ${props.errorText == null ? '' : 'text-danger'}` },
    props.label,
    " ",
    props.isRequired && h("sup", null, "*"),
    props.helptext && (h("i", { class: "tooltip-target material-icons", title: props.helptext }, "help")));
