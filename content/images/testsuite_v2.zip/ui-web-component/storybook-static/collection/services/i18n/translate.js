export const translate = (key, lang, i18n) => i18n[lang][key];
