import { p as patchBrowser, g as globals, b as bootstrapLazy } from './core-e5784005.js';

patchBrowser().then(options => {
  globals();
  return bootstrapLazy([["c-rte",[[0,"c-rte",{"visualMode":[1028,"visual-mode"],"language":[1],"translationKeys":[16],"icons":[1],"editorId":[1,"editor-id"],"isRequired":[4,"is-required"],"label":[1],"errorText":[1,"error-text"],"helptext":[1],"editable":[4],"value":[1025],"textToRender":[32]},[[0,"keydown","handleKeyDown"]]]]],["my-button",[[1,"my-button",{"label":[1]}]]],["my-component",[[1,"my-component",{"first":[1],"middle":[1],"last":[1]}]]]], options);
});
