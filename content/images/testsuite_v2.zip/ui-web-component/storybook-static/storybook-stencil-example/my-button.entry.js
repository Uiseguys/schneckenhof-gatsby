import { r as registerInstance, c as createEvent, h } from './core-e5784005.js';

const MyButton = class {
    constructor(hostRef) {
        registerInstance(this, hostRef);
        this.klick = createEvent(this, "klick", 7);
    }
    handleClick(event) {
        this.klick.emit(event);
    }
    componentWillLoad() {
        console.log('huhuh');
    }
    render() {
        return h("button", { onClick: this.handleClick.bind(this) }, this.label);
    }
    static get style() { return ":host {\n  display: block;\n}"; }
};

export { MyButton as my_button };
