import { Config } from "@stencil/core";
import { sass } from '@stencil/sass'

import builtins from 'rollup-plugin-node-builtins'
import globals from 'rollup-plugin-node-globals'
import { inlineSvg } from 'stencil-inline-svg'


export const config: Config = {
  namespace: "storybook-stencil-example",
  plugins: [
    sass({
      injectGlobalPaths: [
        'src/scss/_global.scss'
      ]
    }),
    builtins(),
    globals(),
    inlineSvg(),
  ],
  outputTargets: [
    {
      type: "dist",
      esmLoaderPath: "../loader"
    },
    {
      type: "docs-readme"
    },
    {
      type: "www",
      serviceWorker: null // disable service workers
    }
  ]
};
