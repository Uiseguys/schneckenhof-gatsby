import { storiesOf } from '@storybook/html';
import { withKnobs, text } from '@storybook/addon-knobs';
import { withActions } from '@storybook/addon-actions';
import { h } from 'jsx-dom';

import readme from './readme.md';

const markdownvalue = `
### Hola!
Welcome to **wysiwyg** [markdown](https://en.wikipedia.org/wiki/Markdown "Wikipedia definition") editor. It supports few
modes:
 * visual
 * raw markdown
 
Feel free to use hotkeys e.g _**Ctrl** + **Shift** + **P**_ to toggle mode.

***feature***

***feat***ure

fe***atu***re

feat***ure***

There are also many features you can use:
 1. **Bold**, _italic_, _**mixed**_, \`variables\`, ~~strikethrough~~, ~subscript~ and ^superscript^ blocks, etc;
 2. Ordered and unordered lists;
 3. Six type of headings, and so on...`

storiesOf('RTE', module)
  .addDecorator(withActions('onClick'))
  .addDecorator(withKnobs)
  .add(
    'Default',
    () => {
      const value = text('value', markdownvalue);
      return (
        <c-rte
          aria-live="polite"
          value={value}
          editable={ false }
          ready={() => {
            console.log('ready from story');
          }}
        ></c-rte>
      );
    },
    {
      notes: {
        markdown: readme,
      },
    }
  );

