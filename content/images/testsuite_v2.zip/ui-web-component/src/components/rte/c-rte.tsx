import { Component, Element, Event, EventEmitter, Listen, Prop, State, Watch, h } from '@stencil/core'
import { DOMParser, Node as ProsemirrorNode } from 'prosemirror-model'
import { EditorState, Transaction } from 'prosemirror-state'
import { setTextSelection } from 'prosemirror-utils'
import { EditorView } from 'prosemirror-view'
import { defaultI18n } from '../../services/i18n/default'
import { MarkdownEditorI18n, MarkdownEditorI18nKey } from '../../services/i18n/keys'
import { translate } from '../../services/i18n/translate'
import { Label } from './functional/label'
import { rawMarkdownSchema, rawPlugins } from './raw'
import { IconThemeType } from './shared/menu/buttonType'
import { getCurrentNodes, omitEscape, randomId, updateViewWithTransaction } from './shared/utils'
import { visualMarkdownParser, visualMarkdownSerializer, visualPlugins } from './visual'
import { HTMLStencilElement } from '@stencil/core/internal';
/**
 * Markdown component class
 *
 * @Prop editable { boolean } is editable property
 * @Prop value { string } initial value of editor
 * @class CwcWysiwygMarkdownEditor
 */
@Component({
  tag: 'c-rte',
  styleUrls: [
    'styles/_main.scss',
    'styles.scss',
    'style.css'
  ],
  shadow: false,
})

export class CwcWysiwygMarkdownEditor {

  private get parsedWithMD(): ProsemirrorNode {
    return visualMarkdownParser.parse(this.textToRender)
  }
  @Prop({ mutable: true }) public visualMode: boolean = true

  @Event() public markdownUpdated: EventEmitter

  @Prop() public language = 'en'
  @Prop() public translationKeys: MarkdownEditorI18n

  @Prop() public icons: IconThemeType = 'material'

  @Prop() public editorId = randomId()
  @Prop() public isRequired = false
  @Prop() public label: string
  @Prop() public errorText: string
  @Prop() public helptext: string

  private translation = defaultI18n

  @Prop() editable: boolean = true
  @Prop({ mutable: true }) value: string = ''

  private visualView: EditorView
  private rawView: EditorView

  @Element() private el: HTMLStencilElement

  @State() private textToRender: string = `## Heading 2
  plain text
  #### Heading 4`

  @Watch('value')
  public valueChangeHandler(newValue: string) {
    this.textToRender = newValue

    this.visualView.updateState(this.createVisualState())
    this.rawView.updateState(this.createRawState())
  }

  public componentWillLoad() {
    this.textToRender = this.value
    this.markdownUpdated.emit(this.textToRender)
  }

  public componentDidLoad() {
    /**
     * Initialization of ProseMirror editor and it state
     */
    this.visualView = this.initVisualView()
    this.rawView = this.initRawView()
    this.handleExportToRaw()

    this.translation = { ...defaultI18n, ...this.translationKeys }

  }

  public render() {
    return [
      <div class="editor-wrapper px-5 pt-2">
        <Label id={`${this.editorId}-label`}
               isRequired={this.isRequired}
               label={this.label}
               errorText={this.errorText}
               helptext={this.helptext}></Label>
        <div id="editor" class={'editor visual ' + this.language + ' ' + this.icons}></div>
        {/* <div id="raw-editor" class="editor raw"></div> */}
        <div id="raw-editor" class={'editor raw hidden ' + this.language + ' ' + this.icons}></div>
      </div>,
      <div class="mode-selector ml-5 mb-2">
        <button class="btn btn-outline-primary btn-sm ml-1" disabled={this.visualMode}
                onClick={() => this.setEditorMode(true)}
                title={this.i18n('visualModeTitle')}>{this.i18n('visualModeLabel')}</button>
        <button class="btn btn-outline-primary btn-sm ml-1" disabled={!this.visualMode}
                onClick={() => this.setEditorMode(false)}
                title={this.i18n('markdownModeTitle')}>{this.i18n('markdownModeLabel')}</button>
      </div>,
      <div id="raw-content" class="raw raw-content"></div>]
  }

  @Listen('keydown')
  public handleKeyDown(evt: KeyboardEvent) {
    if (evt.keyCode === 80 && evt.shiftKey === true && evt.shiftKey === true) {
      evt.preventDefault()

      this.setEditorMode(!this.visualMode)
    }
  }

  private i18n = (key: MarkdownEditorI18nKey) => translate(key, this.language, this.translation)

  private initVisualView(state = this.createVisualState()): EditorView {

    return new EditorView(this.el.querySelector('.editor.visual'), {
      state,
      dispatchTransaction: this.onEditorUpdateHook.bind(this),
      editable: () => this.editable,
      // clipboardParser: () => visualMarkdownParser.parse,
      // handlePaste: (view: EditorView, e: Event, slice: Slice<any>)
    })
  }

  private createVisualState(doc: ProsemirrorNode = this.parsedWithMD): EditorState {
    const plugins = visualPlugins(this.i18n, this.icons)
    return EditorState.create({ doc, plugins })
  }

  private createRawState(): EditorState {
    const doc = DOMParser.fromSchema(rawMarkdownSchema).parse(document.getElementById('raw-content'))
    return EditorState.create({ doc, plugins: rawPlugins(this.i18n, this.icons) })
  }

  private initRawView() {
    return new EditorView(this.el.querySelector('.editor.raw'), {
      state: this.createRawState(),
      dispatchTransaction: this.onRawEditorUpdateHook.bind(this),
    })
  }

  /**
   *  Serialize/parse functions
   */
  private serializeWithMD(view: EditorView = this.visualView): string {
    return visualMarkdownSerializer.serialize(view.state.doc)
  }

  /**
   *  State change handlers
   */
  private handleExportToRaw(): void {
    this.el.querySelector('#raw-content').innerHTML =
      this.el.querySelector('.ProseMirror.ProseMirror-example-setup-style').innerHTML

    this.rawView.updateState(this.createRawState())
  }

  private handleExportToVisual(): void {
    const serialized = this.serializeWithMD(this.rawView)
    this.visualView.updateState(this.createVisualState(visualMarkdownParser.parse(omitEscape(serialized))))
  }

  private onEditorUpdateHook(tr: Transaction<any>): void {
    updateViewWithTransaction(this.visualView, tr)

    if (tr.docChanged) {
      this.markdownUpdated.emit(this.serializeWithMD())
      this.handleExportToRaw()
    }

    this.appendMenuActiveClass()
  }

  private onRawEditorUpdateHook(tr: Transaction): void {
    updateViewWithTransaction(this.rawView, tr)

    if (tr.docChanged) {
      this.markdownUpdated.emit(omitEscape(this.serializeWithMD(this.rawView)))
      this.handleExportToVisual()
    }

    this.appendMenuActiveClass()
  }

  /**
   * Private service functions
   */
  private setEditorMode(mode: boolean, focus = this.editable): void {

    const visual: HTMLDivElement = this.el.querySelector('.editor.visual')
    const raw: HTMLPreElement = this.el.querySelector('.editor.raw')

    if (mode) {
      raw.classList.add('hidden')
      visual.classList.remove('hidden')

      const editor: HTMLDivElement = visual.querySelector('.ProseMirror')
      if (focus) { setTimeout(() =>  {
        editor.focus()
        this.visualView.state.apply(setTextSelection(0, 2)(this.visualView.state.tr))
      }, 0) }
      this.handleExportToVisual()
      this.visualMode = true
    } else if (!mode) {
      visual.classList.add('hidden')
      raw.classList.remove('hidden')
      const editor: HTMLDivElement = raw.querySelector('.ProseMirror')
      if (focus) { setTimeout(() => {

          editor.focus()
          // this.rawView.state.tr.

        }
        , 0) }
      this.handleExportToRaw()
      this.visualMode = false
    }
  }

  private appendMenuActiveClass() {

    const currentNodes = getCurrentNodes(this.visualMode ? this.visualView : this.rawView)
    const inputModeClasses = [
      'active-heading-1',
      'active-heading-2',
      'active-heading-3',
      'active-heading-4',
      'active-heading-5',
      'active-heading-6',
      'paragraph',
    ]

    const dropdownEl: HTMLDivElement = this.el.querySelector(
      `.editor${this.visualMode ? '.visual' : '.raw'} .ProseMirror-menubar .ProseMirror-menu-dropdown-wrap`)
    if (currentNodes.length === 0 || currentNodes.length === 1) {
      inputModeClasses.map((val) => dropdownEl.classList.toggle(val, val === currentNodes[0]))
      if (currentNodes.length === 0) {
        inputModeClasses.map((val) =>
          dropdownEl.classList.toggle(val, dropdownEl.classList.contains(val)))
      }
    }
  }
}
