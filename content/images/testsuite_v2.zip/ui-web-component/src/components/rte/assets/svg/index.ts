import blockquote from './blockquote.svg'
import bold from './bold.svg'
import code from './code.svg'
import horisontalRule from './horisontal-rule.svg'
import italic from './italic.svg'
import link from './link.svg'
import ol from './ol.svg'
import ul from './ul.svg'

// tslint:disable-next-line:interface-name
export interface MarkdownEditorIconSet {
    bold: string
    italic: string
    ul: string
    ol: string
    link: string
    horisontalRule: string
    blockquote: string
    code: string
}

export const set: MarkdownEditorIconSet = {
    bold,
    blockquote,
    ul,
    ol,
    code,
    italic,
    horisontalRule,
    link,
}
