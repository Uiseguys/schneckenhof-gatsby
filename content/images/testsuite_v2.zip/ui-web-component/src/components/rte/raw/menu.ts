import { menuBar } from 'prosemirror-menu'
import { buildMenuItems } from '../shared/menu/buildMenuItems'
import { rawMarkdownSchema } from './schema'

// tslint:disable-next-line:arrow-parens
export const rawMenu = (lang, icons) => menuBar({ content: buildMenuItems(rawMarkdownSchema, icons, lang).fullMenu })
