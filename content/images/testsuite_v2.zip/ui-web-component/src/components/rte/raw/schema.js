import { Schema } from 'prosemirror-model'

const rawMarkdownSpec = {
    nodes: {
        text: {
            group: 'inline',
        },
        // star: {
        //     inline: true,
        //     group: 'inline',
        //     toDOM() { return ['star', '🟊'] },
        //     parseDOM: [{ tag: 'star' }],
        // },
        paragraph: {
            group: 'block',
            content: 'inline*',
            toDOM() { return ['p', 0] },
            parseDOM: [{ tag: 'p' }],
        },
        heading: {
            attrs: { level: { default: 1 } },
            content: 'inline*',
            group: 'block',
            defining: true,
            getContent: () => { },
            parseDOM: [
                { tag: 'h1', attrs: { level: 1 } },
                { tag: 'h2', attrs: { level: 2 } },
                { tag: 'h2', attrs: { level: 2 } },
                { tag: 'h3', attrs: { level: 3 } },
                { tag: 'h4', attrs: { level: 4 } },
                { tag: 'h5', attrs: { level: 5 } },
                { tag: 'h6', attrs: { level: 6 } },
            ],
            toDOM: (node) =>
                [
                    'span',
                    { class: `md-h-${node.attrs.level}` },
                    0,
                ],

        },
        code_block: {
            content: 'text*',
            group: 'block',
            code: true,
            defining: true,
            attrs: { params: { default: '' } },
            parseDOM: [{
                tag: 'pre', preserveWhitespace: true, getAttrs: (node) => (
                    { params: node.getAttribute('data-params') || '' }
                ),
            }],
            toDOM(node) { return [
                'p',
                {class: 'code-block'},
                node.attrs.params ? { 'data-params': node.attrs.params } : {}, ['span', 0]] },
        },
        ordered_list: {
            content: 'list_item+',
            group: 'block',
            attrs: { order: { default: 1 }, tight: { default: false } },
            parseDOM: [{
                tag: 'ol', getAttrs(dom) {
                    return {
                        order: dom.hasAttribute('start') ? +dom.getAttribute('start') : 1,
                        tight: dom.hasAttribute('data-tight'),
                    }
                },
            }],
            toDOM() {
                return ['span', {
                    class: 'ordered-list',
                }, 0]
            },
        },

        bullet_list: {
            content: 'list_item+',
            group: 'block',
            attrs: { tight: { default: false } },
            parseDOM: [{ tag: 'ul', getAttrs: (dom) => ({ tight: dom.hasAttribute('data-tight') }) }],
            toDOM() { return ['span', { class: 'bullet-list' }, 0] },
        },
        list_item: {
            content: 'paragraph block*',
            defining: true,
            parseDOM: [{ tag: 'li' }],
            toDOM() { return ['span', { class: 'list-item' }, 0] },
        },
        doc: {
            content: 'block+',
        },
        blockquote: {
            content: 'block+',
            group: 'block',
            parseDOM: [{ tag: 'blockquote' }],
            toDOM() { return ['p', {class: 'blockquote-paragraph'}, 0] },
        },

        horizontal_rule: {
            group: 'block',
            parseDOM: [{ tag: 'hr' }],
            toDOM() { return ['span', { class: 'horizontal-rule'}, 0] },
        },
    },
    marks: {
        em: {
            parseDOM: [{ tag: 'i' }, { tag: 'em' },
            { style: 'font-style', getAttrs: (value) => value === 'italic' && null }],
            toDOM() { return ['span', { class: 'italic' }] },
        },
        s: {
            parseDOM: [{ tag: 's'}],
            toDOM() { return ['span', { class: 'strike'}]},
        },
        sup: {
            parseDOM: [{ tag: 'sup'}],
            toDOM() { return ['span', { class: 'superscript'}]},
        },
        sub: {
            parseDOM: [{ tag: 'sub'}],
            toDOM() { return ['span', { class: 'subscript'}]},
        },
        strong: {
            parseDOM: [
                { tag: 'b' },
                { tag: 'strong' },
                { style: 'font-weight', getAttrs: (value) => /^(bold(er)?|[5-9]\d{2,})$/.test(value) && null },
            ],
            toDOM() { return ['span', { class: 'bold' }] },
        },
          link: {
              attrs: {
                  href: {},
                  title: {
                      default: null
                  }
              },
              inclusive: false,
              parseDOM: [{
                  tag: "a[href]",
                  getAttrs(dom) {
                      return {
                          href: dom.getAttribute("href"),
                          title: dom.getAttribute("title")
                      }
                  }
              }],
              toDOM(node) {
                  return ["span", {...node.attrs, class: 'link-node'}]
              }
          },

        code: {
            parseDOM: [{ tag: 'code' }],
            toDOM() { return ['span', { class: 'code-string' }] },
        },
    },

}

export const rawMarkdownSchema = new Schema(rawMarkdownSpec)

// export const textSchema = new Schema({
//     nodes: {
//         text: {},
//         doc: { content: "text*" }
//     }
// })

// let starSchema = new Schema({
//     nodes: {
//         text: {
//             group: "inline",
//         },
//         star: {
//             inline: true,
//             group: "inline",
//             toDOM() { return ["star", "🟊"] },
//             parseDOM: [{ tag: "star" }]
//         },
//         paragraph: {
//             group: "block",
//             content: "inline*",
//             toDOM() { return ["p", 0] },
//             parseDOM: [{ tag: "p" }]
//         },
//         boring_paragraph: {
//             group: "block",
//             content: "text*",
//             marks: "",
//             toDOM() { return ["p", { class: "boring" }, 0] },
//             parseDOM: [{ tag: "p.boring", priority: 60 }]
//         },
//         doc: {
//             content: "block+"
//         }
//     },
//     marks: {
//         shouting: {
//             toDOM() { return ["shouting", 0] },
//             parseDOM: [{ tag: "shouting" }]
//         },
//         link: {
//             attrs: { href: {} },
//             toDOM(node) { return ["a", { href: node.attrs.href }, 0] },
//             parseDOM: [{ tag: "a", getAttrs(dom) { return { href: dom.href } } }],
//             inclusive: false
//         }
//     }
// })
// import { toggleMark } from "prosemirror-commands"
// import { keymap } from "prosemirror-keymap"

// let starKeymap = keymap({
//     "Ctrl-b": toggleMark(starSchema.marks.shouting),
//     "Ctrl-q": toggleLink,
//     "Ctrl-Space": insertStar
// })

// function start(place, content, schema, plugins = []) {
//     let doc = DOMParser.fromSchema(schema).parse(content)
//     return new EditorView(place, {
//         state: EditorState.create({
//             doc,
//             plugins: plugins.concat([histKeymap, keymap(baseKeymap), history()])
//         })
//     })
// }
