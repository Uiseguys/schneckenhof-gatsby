// tslint:disable-next-line:interface-name
export interface LabelProps {
    id: string
    isRequired: boolean
    label: string
    errorText: string
    helptext: string
}
