import { FunctionalComponent, h } from '@stencil/core'
import { LabelProps } from './LabelProps'

export /**
 *  Markup component provides form control label.
 *
 * @param LabelProps props
 */
const Label: FunctionalComponent<LabelProps> = (props: LabelProps) =>
    <label
        htmlFor={props.id}
        class={`control-label ${props.errorText == null ? '' : 'text-danger'}`}
    >
        {props.label} {props.isRequired && <sup>*</sup>}
        {props.helptext && (<i class="tooltip-target material-icons" title={props.helptext}>help</i>)}
    </label>
