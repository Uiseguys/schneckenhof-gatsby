export const enum ButtonType {
    STRONG = 'strong',
    EM = 'em',
    UL = 'ul',
    OL = 'ol',
    LINK = 'link',
    BLOCKQUOTE = 'blockquote',
    CODE_BLOCK = 'codeblock',
    HR = 'hr',
    PARENT_NODE = 'parentNode',
    LIFT_OUT = 'liftOut',
    JOIN_UP = 'joinUp',
}

export type IconThemeType = 'material' | 'atlassian' | 'materialDe'

// tslint:disable-next-line:interface-name
export interface IconLabels {
    title?: string
    label?: string
}

// tslint:disable-next-line:interface-name
export interface IconConfig {
    material: {
        className: string,
        icon: {
            text: string,
        },
    },
    materialDe: {
        className: string,
        icon: {
            text: string,
        },
    },
    atlassian: {
        className: string,
        icon: {
            text: string,
        },
    },

    // textLabel?: string,
    // title?: string
}

// tslint:disable-next-line:interface-name
export type IconConfigContainer = {
    [key in ButtonType]: IconConfig
}
