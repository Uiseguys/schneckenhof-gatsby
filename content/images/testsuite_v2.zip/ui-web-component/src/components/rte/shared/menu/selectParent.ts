import { selectParentNode } from 'prosemirror-commands'
import { MenuItem } from 'prosemirror-menu'
import { ButtonType } from './buttonType'
import { constructIcon } from './menuHelpers'

export const selectParentButton = (title: string) => new MenuItem({
    title,
    run: selectParentNode,
    select: (state) => selectParentNode(state),
    icon: constructIcon('material', ButtonType.PARENT_NODE),
    css: '',
    class: '',
    label: '',
    execEvent: ' ',

})
