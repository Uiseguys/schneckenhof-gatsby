/**
 * This helper functions are forked from https://github.com/ProseMirror/prosemirror-example-setup
 * Can be published to npm as separate package `prosemirror-markdown-setup` or similar.
*/

// import { replaceMark } from 'prosemirror-commands'
import hyperscript from 'hyperscript'
import { MenuItem } from 'prosemirror-menu'
import { wrapInList } from 'prosemirror-schema-list'
import { ButtonType, IconLabels } from './buttonType'
import { iconConfig } from './iconConfig'

export function canInsert(state, nodeType) {
    const $from = state.selection.$from
    for (let d = $from.depth; d >= 0; d--) {
        const index = $from.index(d)
        if ($from.node(d).canReplaceWith(index, index, nodeType)) { return true }
    }
    return false
}

export function cmdItem(cmd, options) {
    const passedOptions = {
        label: options.title,
        run: cmd,
        css: options.css || '',
        class: options.class || '',
        execEvent: options.execEvent || '',
    }
    for (const prop in options) {
        if (options[prop]) {
            passedOptions[prop] = options[prop]
        }
    }
    if ((!options.enable || options.enable === true) && !options.select) {
        passedOptions[options.enable ? 'enable' : 'select'] = (state) => cmd(state)
    }

    return new MenuItem(passedOptions)
}

export function markActive(state, type) {
    const { from, $from, to, empty } = state.selection
    if (empty) {
        return type.isInSet(state.storedMarks || $from.marks())
    } else { return state.doc.rangeHasMark(from, to, type) }
}

export function markItem(markType, options) {
    const passedOptions = {
        active(state) { return markActive(state, markType) },
        enable: true,
    }
    for (const prop in options) {
        if (options[prop]) {
            passedOptions[prop] = options[prop]
        }
    }
    return cmdItem(replaceMark(markType), passedOptions)
}

export function wrapListItem(nodeType, options) {
    return cmdItem(wrapInList(nodeType, options.attrs), options)
}


// tslint:disable
export function replaceMark(markType, attrs = {}) {
    return function (state, dispatch) {
        var ref = state.selection
        var $cursor = ref.$cursor
        var ranges = ref.ranges
        if (dispatch) {
            if ($cursor) {
                if (markType.isInSet(state.storedMarks || $cursor.marks())) {
                    dispatch(state.tr.removeStoredMark(markType))
                } else {
                    dispatch(state.tr.addStoredMark(markType.create(attrs)))
                }
            } else {
                var has = false, tr = state.tr
                for (var i = 0; !has && i < ranges.length; i++) {
                    var ref$1 = ranges[i]
                    var $from = ref$1.$from
                    var $to = ref$1.$to
                    has = state.doc.rangeHasMark($from.pos, $to.pos, markType)
                }
                for (var i$1 = 0; i$1 < ranges.length; i$1++) {
                    var ref$2 = ranges[i$1]
                    var $from$1 = ref$2.$from
                    var $to$1 = ref$2.$to
                    if (has) {
                        tr.removeMark($from$1.pos, $to$1.pos, markType)
                    } else {
                        tr.addMark($from$1.pos, $to$1.pos, markType.create(attrs))
                    }
                }
                dispatch(tr.scrollIntoView())
            }
        }
        return true
    }
}

export function constructIcon(theme: string, type: ButtonType, labelData?: IconLabels ) {

    let iconDom

    if ( theme == 'material' || 'materialDe' ) {

        const { className, icon } = iconConfig[type][theme]
        // const { textLabel } = iconConfig[type]
        iconDom =  (
            hyperscript('div.dd-item with-icon',
                hyperscript(`div.${className}`,
                hyperscript('a', icon)
                ),
            labelData && labelData.title && hyperscript('span.dd-label', labelData.title)
            )
        ) 
    }

    // if ( theme == 'materialDe' ) {

    //     const { className, icon } = iconConfig[type][theme]
    //     // const { textLabel } = iconConfig[type]
    //     iconDom =  (
    //         hyperscript('div.dd-item with-icon',
    //             hyperscript(`div.${className}`,
    //             hyperscript('a', icon)
    //             ),
    //         labelData && labelData.title && hyperscript('span.dd-label', labelData.title)
    //         )
    //     ) 
    // }

    if ( theme === 'atlassian') {
        iconDom =  hyperscript('div', 'atl icon')
    }

    return { dom: iconDom }
}

