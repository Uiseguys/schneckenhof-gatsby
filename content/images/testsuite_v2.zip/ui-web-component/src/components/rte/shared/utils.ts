import { Transaction } from 'prosemirror-state'
import { EditorView } from 'prosemirror-view'

/**
 * Apply transaction to ProseMirror View.
 * Always necessary in Transaction handlers.
 *
 * @export
 * @param EditorView view
 * @param Transaction tr
 */
export function updateViewWithTransaction(view: EditorView, tr: Transaction): void {
    view.updateState(view.state.apply(tr))
}

/**
 * Array with marks of current selection.
 *
 * @export
 * @param EditorView editorView
 * @returns {string[]}
 */
export function getCurrentMarks(editorView: EditorView): (any | string[]) {
    const state = editorView.state
    const { from, to } = state.selection

    // Set instead of array because there can't be duplicated values
    const selectionMarks = new Set()

    state.doc.nodesBetween(from, to, (node) => {
        node.marks.forEach((mark) => {
            selectionMarks.add(mark.type.name)
        })
    })

    return Array.from(selectionMarks)
}

export function getCurrentNodes(editorView: EditorView): (any | string[]) {
    const state = editorView.state
    const { from, to } = state.selection

    const nodeTypes = new Set()

    state.doc.nodesBetween(from, to, (node) => {
        nodeTypes.add(node.attrs.level ? `active-${node.type.name}-${node.attrs.level}` : node.type.name)
    })

    return Array.from(nodeTypes).filter((type) => type !== 'text')
}

/**
 * Removes escape symbols from string
 *
 * @param string str
 * @param string [value='']
 * @returns string
 */
export function omitEscape(str: string, value = ''): string {
    return str.replace(/\\/g, value)
}

/**
 * Utility funct
 *
 * @param string length, default = 12
 * @returns string random string
 */
export function randomId(length = 12): string {
    return Math.random().toString(32).substr(2, length)
}
