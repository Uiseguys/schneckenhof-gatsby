import { blockTypeItem, Dropdown, MenuItem, wrapItem } from 'prosemirror-menu'
import { MarkdownEditorI18nKey } from '../../../../services/i18n/keys'
import { ButtonType } from './buttonType'
import { imageItem, ImageTranslateData } from './image'
import { joinUpItem } from './joinAbove'
import { liftItem } from './liftOut'
import { linkItem, LinkTranslationData } from './link'
import { canInsert, constructIcon, markItem, wrapListItem } from './menuHelpers'
import { selectParentButton } from './selectParent'

//tslint:disable
export function buildMenuItems(
	schema, 
	iconTheme = 'material', 
	i18n: (k: MarkdownEditorI18nKey) => string ) {



	// console.log('lang is: ', i18n('headerDefault'));
	
	// iconTheme = 'materialDe'


	let r: any = {}, type: any
	if (type = schema.marks.strong) {
		r.toggleStrong = markItem(type, {
			title: i18n('boldTitle'),
			icon: constructIcon(iconTheme, ButtonType.STRONG)
		})

	}
	if (type = schema.marks.em) {
		const spec = {
			title:  i18n('italicTitle') 
		}
		r.toggleEm = markItem(type, {
			...spec,
			icon: constructIcon(iconTheme, ButtonType.EM)
		})
	}
	if (type = schema.marks.code) {
		r.toggleCode = markItem(type, { title: 'Inline code', label: 'Code' })
	}
	if (type = schema.marks.link) {

		const linkTranslation: LinkTranslationData = {
			title: i18n('linkTitle'),
			linkPromptTitle: i18n('linkPromptTitle'),
			linkPromptHrefPlaceholder: i18n('linkPromptHrefPlaceholder'),
			linkPromptTextPlaceholder: i18n('linkPromptTextPlaceholder')
		}

		r.toggleLink = linkItem(type, 'material', linkTranslation)
	}

	if (type = schema.nodes.image) {

		const imageTranslations: ImageTranslateData = {
			imageTitle: i18n('imageTitle'),
				imageLabel: i18n('imageLabel'),
				imagePromptTitle: i18n('imagePromptTitle'),
				imagePromptFieldLocation: i18n('imagePromptFieldLocation'),
				imagePromptFieldTitle: i18n('imagePromptFieldTitle'),
				imagePromptFieldDescription: i18n('imagePromptFieldDescription'),
		}

		r.insertImage = imageItem(type, imageTranslations)
	}
	if (type = schema.nodes.bullet_list) {
		r.wrapBulletList = wrapListItem(type, {
			title: i18n('ulTitle'),
			icon: constructIcon(iconTheme, ButtonType.UL)
		})
	}
	if (type = schema.nodes.ordered_list) {
		r.wrapOrderedList = wrapListItem(type, {
			
			title :i18n('olTitle'),
			icon: constructIcon(iconTheme, ButtonType.OL)
		}
		)
	}
	if (type = schema.nodes.blockquote) {

		const title = i18n('blockquoteTitle')
		const label = i18n('blockquoteLabel')

		r.wrapBlockQuote = wrapItem(type,
			{
				title: i18n('blockquoteTitle'),
				icon: constructIcon(iconTheme, ButtonType.BLOCKQUOTE, {title, label})
			})
	}
	if (type = schema.nodes.paragraph) {
		r.makeParagraph = blockTypeItem(type, {
			// title: 'Normal text',
			label: i18n('headerDefault'),
		})
	}
	if (type = schema.nodes.code_block) {

		const title = i18n('codeBlockTitle')
		const label = i18n('codeBlockLabel')

		r.makeCodeBlock = blockTypeItem(type, {
			icon: constructIcon(iconTheme, ButtonType.CODE_BLOCK, { title, label} ),
		})
	}
	if (type = schema.marks.s) {
		r.toggleStrikethrough = markItem(type, {
			title: i18n("strikeTitle"),
			label: i18n('strikeLabel'),
		})
	}
	if (type = schema.marks.sub) {
		r.toggleSubscript = markItem(type, {
			title: i18n('subTitle'),
			label: i18n('subLabel'),
		})
	}
	if (type = schema.marks.sup) {
		r.toggleSupercript = markItem(type, {
			title: i18n("superTitle"),
			label: i18n('superLabel'),
		})
	} else {
	}
	if (type = schema.nodes.heading) {
		for (let i = 1; i <= 10; i++) {
			r['makeHead' + i] = blockTypeItem(type, {
				title: i18n("headerTitlePrefix") + ' ' + i,
				label: i18n("headerLabelPrefix") + ' ' + i,
				attrs: { level: i },
			})
		}
	}
	if (type = schema.nodes.horizontal_rule) {
		const hr = type

		const title = i18n('hrTitle')
		const label = i18n('hrLabel')

		r.insertHorizontalRule = new MenuItem({
			title: i18n('hrTitle'),
			label: i18n('hrLabel'),
			// icon: document.getElementById('editor-icon-face'),
			icon: constructIcon(iconTheme, ButtonType.HR, { label, title}),
			enable(state) { return canInsert(state, hr) },
			run(state, dispatch) { dispatch(state.tr.replaceSelectionWith(hr.create())) },
			class: '',
			css: '',
			execEvent: '',

		})
	}

	const cut = (arr) => arr.filter((x) => x)

	r.typeMenu = new Dropdown(
		cut([r.makeParagraph, r.makeHead1, r.makeHead2, r.makeHead3,
		r.makeHead4, r.makeHead5, r.makeHead6]),
		{
			//  label: 'Normal text',
			class: 'headings-dropdown'
		},

	)

	r.nodesDropdown = new Dropdown(
		cut([r.wrapBlockQuote, r.makeCodeBlock, r.insertHorizontalRule,]),
		{ label: '+', title: 'insert', class: 'nodes-menu-dropdown' },

	)
	// r.insertMenu = new Dropdown(
	//     cut([r.makeCodeBlock, r.insertImage, r.insertHorizontalRule]), { label: '...' },
	// )

	r.inlineMenu = [cut([r.toggleStrong, r.toggleEm, new Dropdown(
		cut(
			[r.toggleStrikethrough, r.toggleSubscript, r.toggleSupercript, r.insertImage,]
		), { label: '...', class: 'inline-menu-dropdown', title: i18n('insertMenuTitle') },
	)])]

	r.blockMenu = [cut([r.toggleLink, /*r.wrapBulletList, r.wrapOrderedList,*/  joinUpItem(i18n('joinTitle')),
		liftItem(i18n('liftTitle')), selectParentButton(i18n('parentTitle')), r.nodesDropdown])]

	r.fullMenu = [[r.typeMenu]].concat(r.inlineMenu, /*[[undoItem, redoItem]], */[[r.wrapBulletList, r.wrapOrderedList,]], r.blockMenu)

	return r
}