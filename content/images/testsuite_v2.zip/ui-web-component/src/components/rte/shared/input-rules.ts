import { ellipsis, emDash, InputRule, inputRules, smartQuotes, textblockTypeInputRule, wrappingInputRule } from 'prosemirror-inputrules'
// import { schema } from './schema'
import { Mark as PMMark, MarkType, Schema } from 'prosemirror-model'
import { EditorState, Transaction } from 'prosemirror-state'

// : (NodeType) → InputRule
// Given a blockquote node type, returns an input rule that turns `"> "`
// at the start of a textblock into a blockquote.
export function blockQuoteRule(nodeType) {
    return wrappingInputRule(/^\s*>\s$/, nodeType)
}

// : (NodeType) → InputRule
// Given a list node type, returns an input rule that turns a number
// followed by a dot at the start of a textblock into an ordered list.
export function orderedListRule(nodeType) {
    return wrappingInputRule(/^(\d+)\.\s$/, nodeType, (match) => ({ order: +match[1] }),
        (match, node) => node.childCount + node.attrs.order === +match[1])
}

// : (NodeType) → InputRule
// Given a list node type, returns an input rule that turns a bullet
// (dash, plush, or asterisk) at the start of a textblock into a
// bullet list.
export function bulletListRule(nodeType) {
    return wrappingInputRule(/^\s*([-+*])\s$/, nodeType)
}

// : (NodeType) → InputRule
// Given a code block node type, returns an input rule that turns a
// textblock starting with three backticks into a code block.
export function codeBlockRule(nodeType) {
    return textblockTypeInputRule(/^```$/, nodeType)
}

// : (NodeType, number) → InputRule
// Given a node type and a maximum level, creates an input rule that
// turns up to that number of `#` characters followed by a space at
// the start of a textblock into a heading whose level corresponds to
// the number of `#` signs.
export function headingRule(nodeType, maxLevel) {
    return textblockTypeInputRule(new RegExp('^(#{1,' + maxLevel + '})\\s$'),
        nodeType, (match) => ({ level: match[1].length }))
}

export const markInputRule = (regexp, markType, getAttrs?) => {
    const newRegexp = new RegExp(regexp.source.replace(/\$$/, '') + '(.)' + '$')

    return new InputRule(newRegexp, (state, match, start, end) => {
        const attrs = getAttrs instanceof Function ? getAttrs(match) : getAttrs
        const textStart = start + match[0].indexOf(match[1])
        const textEnd = textStart + match[1].length
        const tr = state.tr

        start = (match[0].match(/^\s/)) ? start + 1 : start

        if (textEnd < end) { tr.delete(textEnd, end) }
        if (textStart > start) { tr.delete(start, textStart) }

        end = start + match[1].length

        return tr
            .addMark(start, end, markType.create(attrs))
            .removeStoredMark(markType)
        // .insert(end, schema.text(match[2]))
    })
}

// : (Schema) → Plugin
// A set of input rules for creating the basic block quot:es, lists,
// code blocks, and heading.
// tslint:disable
export function buildInputRules(schema) {

    let rules = smartQuotes.concat(ellipsis, emDash)
    //  type
    if ( schema.nodes && schema.nodes.blockquote) { 
        rules.push(blockQuoteRule(schema.nodes.blockquote))
     }
    if ( schema.nodes && schema.nodes.ordered_list) { 
        rules.push(orderedListRule(schema.nodes.ordered_list)) 
    }
    if ( schema.nodes && schema.nodes.bullet_list) { 
        rules.push(bulletListRule(schema.nodes.bullet_list)) 
    }
    if ( schema.nodes && schema.nodes.code_block) { 
        rules.push(codeBlockRule(schema.nodes.code_block)) 
    }
    if ( schema.nodes && schema.nodes.heading) { 
        rules.push(headingRule(schema.nodes.heading, 6)) 
    }


    // if (schema.marks.strong) rules.push(markInputRule(/(?:\*\*|__)([^\*_]+)(?:\*\*|__)$/, schema.marks.strong))
    if (schema.marks.strong) rules.push(...getStrongInputRules(schema))
    if (schema.marks.em) rules.push(...getItalicInputRules(schema))
 

    return inputRules({ rules })
}




export const strongRegex1 = /(\S*)(\_\_([^\_\s](\_(?!\_)|[^\_])*[^\_\s]|[^\_\s])\_\_)$/;
export const strongRegex2 = /(\S*)(\*\*([^\*\s](\*(?!\*)|[^\*])*[^\*\s]|[^\*\s])\*\*)$/;
export const mixedRegex = /(\S*)(\*\*\*([^\*\s](\*(?!\*)|[^\*])*[^\*\s]|[^\*\s])\*\*\*)$/;
export const italicRegex1 = /(\S*[^\s\_]*)(\_([^\s\_][^\_]*[^\s\_]|[^\s\_])\_)$/;
export const italicRegex2 = /(\S*[^\s\*]*)(\*([^\s\*][^\*]*[^\s\*]|[^\s\*])\*)$/;
export const strikeRegex = /(\S*)(\~\~([^\s\~](\~(?!\~)|[^\~])*[^\s\~]|[^\s\~])\~\~)$/;
export const codeRegex = /(\S*)(`[^\s][^`]*`)$/;


function getItalicInputRules(schema: Schema): InputRule[] {

    // *string* or _string_ should italic the text
    const markLength = 1;

    const underscoreRule = createInputRule(
        italicRegex1,
        addMark(schema.marks.em, schema, markLength, '_'),
    );

    const asterixRule = createInputRule(
        italicRegex2,
        addMark(schema.marks.em, schema, markLength, '*'),
    );

    return [
        underscoreRule,
        asterixRule,
    ];
}

function getStrongInputRules(schema: Schema): InputRule[] {
    const markLength = 2;
    const doubleUnderscoreRule = createInputRule(
        strongRegex1,
        addMark(schema.marks.strong, schema, markLength, '__'),
    );

    const doubleAsterixRule = createInputRule(
        strongRegex2,
        addMark(schema.marks.strong, schema, markLength, '**'),
    );

    return [
        doubleUnderscoreRule,
        doubleAsterixRule,
    ];
}

export function defaultInputRuleHandler(
    inputRule: InputRuleWithHandler,
    isBlockNodeRule: boolean = false,
): InputRuleWithHandler {
    const originalHandler = (inputRule as any).handler;
    inputRule.handler = (state: EditorState, match, start, end) => {
        // Skip any input rule inside code
        // https://product-fabric.atlassian.net/wiki/spaces/E/pages/37945345/Editor+content+feature+rules#Editorcontent/featurerules-Rawtextblocks
        const unsupportedMarks = isBlockNodeRule
            ? hasUnsupportedMarkForBlockInputRule(state, start, end)
            : hasUnsupportedMarkForInputRule(state, start, end);
        if (state.selection.$from.parent.type.spec.code || unsupportedMarks) {
            return;
        }
        return originalHandler(state, match, start, end);
    };
    return inputRule;
}

export type InputRuleWithHandler = InputRule & { handler: InputRuleHandler };
export type InputRuleHandler = ((
    state: EditorState,
    match: Array<string>,
    start: number,
    end: number,
) => Transaction | null);

export function createInputRule(
    match: RegExp,
    handler: InputRuleHandler,
    isBlockNodeRule: boolean = false,
): InputRuleWithHandler {
    return defaultInputRuleHandler(
        new InputRule(match, handler) as InputRuleWithHandler,
        isBlockNodeRule,
    );
}


const hasUnsupportedMarkForBlockInputRule = (
    state: EditorState,
    start: number,
    end: number,
) => {
    const {
        doc,
        schema: { marks },
    } = state;
    let unsupportedMarksPresent = false;
    const isUnsupportedMark = (node: PMMark) =>
        node.type === marks.code ||
        node.type === marks.link ||
        node.type === marks.typeAheadQuery;
    doc.nodesBetween(start, end, node => {
        unsupportedMarksPresent =
            unsupportedMarksPresent ||
            node.marks.filter(isUnsupportedMark).length > 0;
    });
    return unsupportedMarksPresent;
};

const hasUnsupportedMarkForInputRule = (
    state: EditorState,
    start: number,
    end: number,
) => {
    const {
        doc,
        schema: { marks },
    } = state;
    let unsupportedMarksPresent = false;
    const isCodemark = (node: PMMark) =>
        node.type === marks.code || node.type === marks.typeAheadQuery;
    doc.nodesBetween(start, end, node => {
        unsupportedMarksPresent =
            unsupportedMarksPresent || node.marks.filter(isCodemark).length > 0;
    });
    return unsupportedMarksPresent;


}
const validCombos = {
    '**': ['_', '~~'],
    '*': ['__', '~~'],
    __: ['*', '~~'],
    _: ['**', '~~'],
    '~~': ['__', '_', '**', '*'],
};

export type ValidCombosKey = keyof typeof validCombos;


const validRegex = (char: ValidCombosKey, str: string): boolean => {
    for (let i = 0; i < validCombos[char].length; i++) {
        const ch = validCombos[char][i];
        if (ch === str) {
            return true;
        }
        const matchLength = str.length - ch.length;
        if (str.substr(matchLength, str.length) === ch) {
            return validRegex(ch as ValidCombosKey, str.substr(0, matchLength));
        }
    }
    return false;
};

function addMark(
  markType: MarkType,
  schema: Schema,
  charSize: number,
  char: ValidCombosKey,
): InputRuleHandler {
  return (state, match, start, end) => {
    const [, prefix, textWithCombo] = match;
    const to = end;
    // in case of *string* pattern it matches the text from beginning of the paragraph,
    // because we want ** to work for strong text
    // that's why "start" argument is wrong and we need to calculate it ourselves
    const from = textWithCombo ? start + prefix.length : start;
    const nodeBefore = state.doc.resolve(start + prefix.length).nodeBefore;

    if (
      prefix &&
      prefix.length > 0 &&
      !validRegex(char, prefix) &&
      !(nodeBefore && nodeBefore.type === state.schema.nodes.hardBreak)
    ) {
      return null;
    }
    // fixes the following case: my `*name` is *
    // expected result: should ignore special characters inside "code"
    if (
      state.schema.marks.code &&
      state.schema.marks.code.isInSet(state.doc.resolve(from + 1).marks())
    ) {
      return null;
    }

    // Prevent autoformatting across hardbreaks
    let containsHardBreak: boolean | undefined;
    state.doc.nodesBetween(from, to, node => {
      if (node.type === schema.nodes.hardBreak) {
        containsHardBreak = true;
        return false;
      }
      return !containsHardBreak;
    });
    if (containsHardBreak) {
      return null;
    }

    // fixes autoformatting in heading nodes: # Heading *bold*
    // expected result: should not autoformat *bold*; <h1>Heading *bold*</h1>
    if (state.doc.resolve(from).sameParent(state.doc.resolve(to))) {
      if (!state.doc.resolve(from).parent.type.allowsMarkType(markType)) {
        return null;
      }
    }



    // apply mark to the range (from, to)
    let tr = state.tr.addMark(from, to, markType.create());

    if (charSize > 1) {
      // delete special characters after the text
      // Prosemirror removes the last symbol by itself, so we need to remove "charSize - 1" symbols
      tr = tr.delete(to - (charSize - 1), to);
    }

    return (
      tr
        // delete special characters before the text
        .delete(from, from + charSize)
        .removeStoredMark(markType)
    );
  };
}



    