# cwc-wysiwyg-markdown-editor



<!-- Auto Generated Below -->


## Properties

| Property          | Attribute     | Description | Type                                        | Default      |
| ----------------- | ------------- | ----------- | ------------------------------------------- | ------------ |
| `editable`        | `editable`    |             | `boolean`                                   | `true`       |
| `editorId`        | `editor-id`   |             | `string`                                    | `randomId()` |
| `errorText`       | `error-text`  |             | `string`                                    | `undefined`  |
| `helptext`        | `helptext`    |             | `string`                                    | `undefined`  |
| `icons`           | `icons`       |             | `"atlassian" \| "material" \| "materialDe"` | `'material'` |
| `isRequired`      | `is-required` |             | `boolean`                                   | `false`      |
| `label`           | `label`       |             | `string`                                    | `undefined`  |
| `lang`            | `lang`        |             | `string`                                    | `'en'`       |
| `translationKeys` | --            |             | `MarkdownEditorI18n`                        | `undefined`  |
| `value`           | `value`       |             | `string`                                    | `''`         |
| `visualMode`      | `visual-mode` |             | `boolean`                                   | `true`       |


## Events

| Event             | Description | Type                |
| ----------------- | ----------- | ------------------- |
| `markdownUpdated` |             | `CustomEvent<void>` |


----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
