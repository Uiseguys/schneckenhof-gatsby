import { baseKeymap, toggleMark } from 'prosemirror-commands'
import { exampleSetup } from 'prosemirror-example-setup'
import { keymap } from 'prosemirror-keymap'
import { menuBar } from 'prosemirror-menu'
import { buildInputRules } from '../shared/input-rules'
import { buildMenuItems } from '../shared/menu/buildMenuItems'
import { schema } from './schema'

const visualBindings = keymap({
    'Ctrl+b': toggleMark(schema.marks.strong),
    'Ctrl+i': toggleMark(schema.marks.em),
    'Ctrl+s': toggleMark(schema.marks.s),
    'Ctrl+m': toggleMark(schema.marks.code),
})

// tslint:disable-next-line:arrow-parens
export const visualPlugins = (lang, icons) => [
    ...exampleSetup({ schema, menuBar: false }),
    buildInputRules( schema),
    keymap(baseKeymap),
    visualBindings,
    menuBar({ content: buildMenuItems(schema, icons, lang).fullMenu }),
]
