import { storiesOf } from '@storybook/html';

import readme from './readme.md';

storiesOf('Modal', module).add(
  'Default',
  () =>
    '<h3>Modal</h3>' +
    '<button onClick={document.getElementsByTagName("c-modal")[0].openModal()}>show modal</button>' +
    '<c-modal>' +
    'my modal content' +
    '</c-modal>',
  {
    notes: {
      markdown: readme,
    },
  }
);
