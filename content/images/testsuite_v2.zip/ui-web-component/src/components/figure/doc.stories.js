import { storiesOf } from '@storybook/html';

import readme from './readme.md';

storiesOf('Figure', module).add(
  'Default',
  () =>
    '<h3>Picture</h3>' +
    '<c-figure imgsrc="http://placehold.it/400x100"></c-figure>' +
    '<h3>Picture with Caption</h3>' +
    '<c-figure imgsrc="http://placehold.it/400x100" captionhead="The image shows a generated placeholder grafic"></c-figure>',
  {
    notes: {
      markdown: readme,
    },
  }
);
