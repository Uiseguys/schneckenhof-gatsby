import { Component, Prop, h } from '@stencil/core';

@Component({
  tag: 'c-figure',
  styleUrl: 'styles.scss',
  shadow: false,
})
export class Figure {
  /**
   * Image Source
   */
  @Prop() imgsrc: string;

  /**
   * Picture Source Data-SrcSet
   */
  @Prop() sourceset: string = 'http://placehold.it/400x300 400w, http://placehold.it/700x300 700w, http://placehold.it/800x400 800w, http://placehold.it/960x300 960w, http://placehold.it/1400x400 1000w, http://placehold.it/1920x500 1920w';

  /**
   * Picture Source Data-SrcSet
   */
  @Prop() alttext: string = 'Alternative text that describes the image';

  /**
   * Placeholder - In Case Video is not started or Image is not loaded yet
   */
  @Prop() placeholder: string = 'Alternative text that describes the image';

  /**
   * Video Sources
   */
  @Prop() videosrcs: string[];

  /**
   * Video Source Types
   */
  @Prop() videotypes: string[];

  /**
   * Caption header
   */
  @Prop() captionhead: string;

  /**
   * Caption body
   */
  @Prop() captionbody: string;

  render() {
    return [
      <figure class="c-figure--caption" data-css="c-figure" id="figure-caption">

        <div class="figure__wrapper">

          {this.imgsrc && (

            <picture class="c-picture--default lazyload" data-css="c-picture">
              <source data-srcset={this.sourceset}/>
              <img class="picture__image lazyload"
                   src={this.imgsrc}
                   alt={this.alttext}/>
            </picture>

          )}

          {this.videosrcs && (

            <video class="c-video--default" data-css="c-video" poster={this.placeholder} controls>
              <source src={this.videosrcs[0]}
                      type={this.videotypes[0]}/>
              <source src={this.videosrcs[1]}/>
              <track src="" kind="" srcLang="" label=""/>
            </video>

          )}

        </div>

        <figcaption class="figure__caption">
          <div class="figure__caption-inner">
            <h3 class="figure__caption-headline">{this.captionhead}</h3>
            <p class="figure__caption-content">{this.captionbody}</p>
          </div>
        </figcaption>

      </figure>
    ]
  }
}
