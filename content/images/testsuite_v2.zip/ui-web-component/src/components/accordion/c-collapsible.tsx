import { Component, Prop, State, h, Method, Element } from '@stencil/core';

@Component({
  tag: 'c-collapsible',
  styleUrl: 'styles.scss',
  shadow: true,
})
export class Accordion {

  /**
   * title
   */
  @Prop() caption: string;

  /**
   * expand - define if content is initially expanded/visible
   */
  @Prop() expand: boolean;

  /**
   * internal state
   */
  @State() expanded: boolean;

  /**
   * uid
   */
  private uid: string =
    'c-collapsible-' + Math.floor(1000 + Math.random() * 9000) + new Date().getUTCMilliseconds();

  @Element() el: HTMLElement;
  header: HTMLElement;
  content: HTMLElement;


  toggleExpanded (e) {
    this.expanded = !this.expanded;
    console.log('this.expanded:');
    console.log(this.expanded);
    console.log('e:');
    console.log(e);

    if (this.expanded) {
      this.content.focus()
    } else {
      this.header.focus()
    }
  }

  toggleExpandedKey (e) {

    console.log('in togglekey e:');

    console.log('e:');
    console.log(e);

    if (e.code && (e.code === 'Space' || e.code === 'Enter')) {
      this.expanded = !this.expanded;
      console.log('this.expanded:');
      console.log(this.expanded);

      if (this.expanded) {
        this.content.focus()
      } else {
        this.header.focus()
      }
    }
  }

  render() {
    return [
      <div class="collapsible-wrapper">

        <h3
          tabindex="0"
          role="button"
          aria-expanded={ this.expanded }
          ref={(el) => this.header = el as HTMLInputElement}
          id={`accordion-control-${ this.uid }`}
          aria-controls={`content-${ this.uid }`}
          onClick={(e) => this.toggleExpanded(e)}
          onKeyDown={(e) => this.toggleExpandedKey(e)}>
          { this.caption }
        </h3>

        <div
          class={{
            'hidden': !this.expanded,
            'accordion__content-inner': true
          }}
          aria-hidden={ !this.expanded }
          ref={(el) => this.content = el as HTMLInputElement}
          id={`content-${ this.uid }`} tabindex="0">

          <slot></slot>

        </div>
      </div>
    ]
  }
}
