import { Component, h } from '@stencil/core';

@Component({
  tag: 'c-accordion',
  styleUrl: 'styles.scss',
  shadow: true,
})
export class Accordion {

  render() {
    return [
      <div class="accordion-wrapper">
        <slot></slot>
      </div>
    ]
  }
}
