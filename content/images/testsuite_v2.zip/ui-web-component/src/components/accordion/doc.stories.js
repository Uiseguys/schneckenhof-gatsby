import { storiesOf } from '@storybook/html';

import readme from './readme.md';

storiesOf('Accordion', module).add(
  'Default',
  () =>
    '<h3>Accordion</h3>' +
    '<c-accordion>' +
    '<c-collapsible caption="my contenttitle 1">My Content 1</c-collapsible>' +
    '<c-collapsible caption="my contenttitle 2">My Content 2</c-collapsible>' +
    '</c-accordion>',
  {
    notes: {
      markdown: readme,
    },
  }
);
