# my-component



<!-- Auto Generated Below -->


## Properties

----------------------------------------------

*Built with [StencilJS](https://stenciljs.com/)*
