import { MarkdownEditorI18n, MarkdownEditorI18nKey } from './keys'

export const translate = (key: MarkdownEditorI18nKey, lang: string, i18n: MarkdownEditorI18n): string =>
    i18n[lang][key]
